
public class Sony extends Company {
	
	
    public int price(){   
        return 20;  
}  
@Override  
public String pack(){  
return "Sony CD";  
}        

}
