/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author filzahamjad
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Circle object= new Circle();
        System.out.println(object.getArea());
        System.out.println(object.getColor());
        Circle object1= new Circle(6.0);
        System.out.println(object1.getArea());
        System.out.println(object1.getColor());
        Circle object2= new Circle(5.0,"purple");
        System.out.println(object2.getArea());
        System.out.println(object2.getColor());        
    }
    
}
