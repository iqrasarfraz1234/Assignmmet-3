
public interface Shape {

}
