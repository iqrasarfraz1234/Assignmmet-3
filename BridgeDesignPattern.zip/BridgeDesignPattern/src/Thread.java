
public interface Thread {
	
	
	public void preemtiveshedular();
	public void timesliceshedular();

}
