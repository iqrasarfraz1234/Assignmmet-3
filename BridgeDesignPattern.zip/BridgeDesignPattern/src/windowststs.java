
public class windowststs implements Thread{

	
	
	public void categorytype() {
				
		
		
	}

	@Override
	public void preemtiveshedular() {
	
		
	}

	@Override
	public void timesliceshedular() {
		System.out.println("Time Slice Shedular");
		
	}

}
