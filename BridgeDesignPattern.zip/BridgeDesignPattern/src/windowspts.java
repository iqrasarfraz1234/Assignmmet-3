
public class windowspts implements Thread {


	
	public void categorytype() {
		
		

	}


	@Override
	public void preemtiveshedular() {
		
		System.out.println("Base Preemtive Shedular");
	}


	@Override
	public void timesliceshedular() {
	
		
	}


}
