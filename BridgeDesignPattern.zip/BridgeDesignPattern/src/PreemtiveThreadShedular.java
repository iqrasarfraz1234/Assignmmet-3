
public class PreemtiveThreadShedular extends  ThreadShedular {

	PreemtiveThreadShedular(Thread c) {
		super(c);
		// TODO Auto-generated constructor stub
	}

	@Override
	void preemtiveshedular() {
		
		System.out.println("Base Preemtive Shedular");
	}

	@Override
	void timesliceshedular() {
		// TODO Auto-generated method stub
		
	}




	

}
