
public class MainDemo {

	public static void main(String[] args) {
		
		
		
		

		
		ThreadShedular obj=new PreemtiveThreadShedular(new windowspts());
		obj.preemtiveshedular();
		
		
		ThreadShedular obj1=new TimedSliceShedular(new windowststs());
        obj1.timesliceshedular();
		
		
		
		
		
		

	}



}
